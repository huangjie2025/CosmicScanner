CosmicScanner v2.0.0 macOS acceptance package
macOS 15.0 or later. Choose arm64 for Apple Silicon, x86_64 for Intel.
Unpack the entire folder; keep bin/ and lib/ together.
Run from the package folder: ./bin/cosmicscanner --help
See docs/NATIVE_INSTALL_CN.md for a complete runnable example.
No Python, Homebrew or compiler is required to run the software.
Python 3 is only required for the optional test/verify_native_package.py.
This package passed the recorded macOS CLI and example tests.
This does not certify every scientific model as stable.
Ad-hoc signed; not Apple Developer ID signed or notarized.
