The original supplied archive contained no README.txt.
