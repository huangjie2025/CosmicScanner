CosmicScanner 2.0.0: ACCEPTANCE PACKAGE, not yet a stable certification.
Unpack the whole folder, keeping the executable and libraries together.
Windows: .\bin\cosmicscanner.exe --help
macOS: ./bin/cosmicscanner --help
Self-test (Python 3, only required for verification): python test/verify_native_package.py
Detailed source-build examples in docs use different binary/data paths.
Do not treat experimental models in help as stable functionality.
macOS ad-hoc signature is not Apple Developer ID notarization.
