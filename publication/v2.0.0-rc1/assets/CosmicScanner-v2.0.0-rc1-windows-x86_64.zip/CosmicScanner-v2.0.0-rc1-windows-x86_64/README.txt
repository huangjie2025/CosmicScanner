CosmicScanner v2.0.0-rc1 — Release candidate
Platform: Windows / x86_64
Requirement: Windows 10 1903+ recommended

This is the RC1 distribution of the supplied v2.0.0 executable. The executable
may report v2.0.0; retain PACKAGE_ID.json to identify this distribution precisely.
The original executable, runtime libraries and license files are unchanged.
The original package status was RELEASE_CANDIDATE; original metadata and README
are retained in provenance/. Packaging changes do not certify a scientific model
or establish new compatibility results. This is not a stable release.
PACKAGE_ID.json distinguishes the candidate reference from a verified binary
build commit. Original reported source fields and public workflow metadata are
recorded separately. A source-to-binary match has not been independently verified.

Unpack the complete folder and keep bin/, lib/ and (where present) libexec/
together. No Python or compiler is required to run an analysis.
Run from this package directory:
  .\bin\cosmicscanner.exe --version
  .\bin\cosmicscanner.exe --help
Create a demo_results directory, then run:
  .\bin\cosmicscanner.exe gwas --model lmm --bfile examples/dataset/synth --pheno examples/dataset/quantitative.pheno --mpheno 1 --threads 1 --out demo_results/lmm
In Windows PowerShell, put & before a quoted executable path.

The common synthetic example contains 60 individuals and 180 variants.
The LMM association output has P_A, BETA_A and SE_A columns. Keep the log,
run manifest and scan metadata with the results. A completed synthetic example
checks the workflow; it is not a scientific benchmark or model validation.
Longitudinal random regression and other experimental paths remain experimental.

Documentation:
  docs/USER_MANUAL_EN.md                Complete English manual
  docs/CosmicScanner_v2.0.0_User_Manual_EN.docx   English Word manual
  docs/USER_MANUAL_CN.md                Complete Chinese manual
  docs/CosmicScanner_v2.0.0_User_Manual_CN.docx   Chinese Word manual
  docs/USER_MANUAL_EN_QUICK.md          English quick start
  docs/CLI_GUIDE_EN.md and CLI_GUIDE_CN.md       CLI guides
  docs/NATIVE_INSTALL_CN.md             Chinese platform guide

Optional four-workflow self-test (Python 3 only required for this check):
  python test/verify_native_package.py
On macOS/Linux use python3 if that is the installed command.
The check covers LMM, multivariate, repeatability and GRM examples, not RRM.

macOS packages retain their original ad-hoc signature. They have not been
Developer ID signed or notarized. Verify the archive checksum before use.
SHA256SUMS covers every packaged file except SHA256SUMS itself.
LICENSE and licenses/ contain the software and bundled dependency licenses.
